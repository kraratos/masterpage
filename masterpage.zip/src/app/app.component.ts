import { Component, DestroyRef, inject, OnInit } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { finalize, from, map, mergeMap } from 'rxjs';
import layoutResponse from '../assets/layoutResponse/layoutResponse.json';
import { Pages } from 'src/enum/enums';
import { TIMELINE_WIDGETID } from 'src/constants/constant';
import { DataService } from 'src/services/data.service';
import { CpProxyDataApiService } from 'src/services/api/cp-proxy-data-api.service';


@Component({
  selector: 'app-micro-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Micro App Template';
  private destroyRef: DestroyRef = inject(DestroyRef);
  responselayout: any;
  
    constructor(public dataService: DataService, private cpProxyDataService: CpProxyDataApiService,) { }
    
    updateWidgeData() {

      let response = layoutResponse;
      let page = Pages.STRATEGY;

          const pageFound = response?.pages?.find((p: any) => p?.name === page);
      
          const tmpWidgets: any[] = [
            ...(pageFound?.summary ?? [])
          ];
          if (pageFound?.kpis) tmpWidgets.push(pageFound.kpis);
      
          if (pageFound?.options) {
            this.dataService.setOptionsMicroAppLayoutSubject(pageFound.options);
          }
          const widgets: any[] = tmpWidgets.filter(w => w?.id !== TIMELINE_WIDGETID);

      from(widgets).pipe(
        mergeMap(widget => {
          let payload: any = {
            widgetId: 138,
            vid : "PR_NOBLE",
            dateRange: "3M",
            level: "projects"
          };
          return this.cpProxyDataService.getWidgetData(payload).pipe(
            map((result: any) => ({ payload, result } as { payload: any; result: any })),
            finalize(() => console.debug('[CP-PROXY-REQ FINALIZE]', payload))
          );
        })
      ).pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe((value) => {
          const { payload, result } = value as { payload: any; result: any };
        })
  
    }
      pageSelected($event: any) {
    
        //this.dataService.cancelAllPendingRequest()
        setTimeout(() => {
          this.updateWidgeData()
        }, 0)
    
      }
}
