import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/shared.module';
import { MicroAppComponent } from "src/pages";
import { MicroAppProjectsRoutingModule } from "./microapp-routing.module"
import {ComponentLibraryModule} from "@bh-digital-solutions/ui-toolkit-angular/dist";
import { WidgetsSelectorLibModule } from '@bakerhughes-icenter/widgets-selector-lib';
import {MaintenanceOptimizerSinottico} from '@bakerhughes-icenter/wd-hcm-lib'
import {CaseTableLibModule} from '@bakerhughes-icenter/lib-casestable-wd'
import { EfficiencyComponent } from 'src/pages/efficiency/efficiency.component';
import { HealthComponent } from 'src/pages/health/health.component';
import { StrategyComponent } from 'src/pages/strategy/strategy.component';
import { UnmanningComponent } from 'src/pages/unmanning/unmanning.component';
import { KPIsAxCoEfficiencyLibModule } from '@bakerhughes-icenter/kpisaxcoefficiency-lib'; 
import { EventTimelineLibModule} from '@bakerhughes-icenter/event-time-lib'
import { TableViewModule } from '@bakerhughes-icenter/table-view-lib';
import { GenericTimeSerieLibModule } from '@bakerhughes-icenter/generic-timeserie-lib';
import { WidgetContainerComponent } from 'src/pages/widget-container/widget-container.component';
import { DetailComponent } from 'src/pages/detail/detail.component';
//import { EventTimelineLibModule } from 'lib/event-time-lib';



@NgModule({
  declarations: [
  ],
  imports: [CommonModule, SharedModule, MicroAppProjectsRoutingModule, ComponentLibraryModule]
})
export class MicroAppModule { }
