import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";
import {UserSettingsResponse} from "src/interface";
import {LayoutResponse} from "src/interface/layout-response";
import {HttpAbstractBackendService} from "./abstract/http-abstract-backend.service";
import {HttpOptionsRequestInterface} from "src/interface/http/http-options-request-interface";
import {clone} from "underscore";
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CpUserManagementService extends HttpAbstractBackendService{
  private _baseUrlApi:string = 'cp-usermaangement-service';
  private _uriServiceApi:string = 'v1';

  private _defaultOptions: HttpOptionsRequestInterface =
    {
      observe: "body",
      headers: new HttpHeaders({
        'Accept':'application/json',
        'Content-Type':  ['application/json'],
      }),
      //params?: HttpParams|{[param: string]: string | number | boolean | ReadonlyArray<string | number | boolean>},
      //reportProgress?: boolean,
      //responseType?: 'arraybuffer'|'blob'|'json'|'text',
      //withCredentials?: boolean,
    };

  constructor(http: HttpClient) {
    super(http);
    this.setApiConfig();
  }

  private setApiConfig(){
    this.baseUrl = '';
  }
  public getUserInfo():Observable<UserSettingsResponse[]>{
    return this.getRequest<any>(environment.me,this._defaultOptions);
  }
  
}
