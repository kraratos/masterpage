import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { finalize, Observable, tap } from "rxjs";
import { UserSettingsResponse } from "src/interface";
import { LayoutResponse } from "src/interface/layout-response";
import { HttpAbstractBackendService } from "./abstract/http-abstract-backend.service";
import { HttpOptionsRequestInterface } from "src/interface/http/http-options-request-interface";
import { clone } from "underscore";
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CpProxyDataApiService extends HttpAbstractBackendService {
  private _baseUrlApi: string = 'cp-proxy-data-service';
  private _uriServiceApi: string = 'v1';

  private _defaultOptions: HttpOptionsRequestInterface =
    {
      observe: "body",
      headers: new HttpHeaders({
        'Accept': 'application/json',
        'Content-Type': ['application/json'],
      }),
      //params?: HttpParams|{[param: string]: string | number | boolean | ReadonlyArray<string | number | boolean>},
      //reportProgress?: boolean,
      //responseType?: 'arraybuffer'|'blob'|'json'|'text',
      //withCredentials?: boolean,
    };

  constructor(http: HttpClient) {
    super(http);
    this.setApiConfig();
  }

  private setApiConfig() {
    this.baseUrl ="";
  }

  /**
   * get the list of the widgets for the user ,list is filtered  by active and enabled serivice
   * payload example {
   *          "vid": "PR_QAFCO",
   *          "pageName": "health",
   *          "microAppName": "masterpageapp"
   * }
   * @param payload
   * @returns
   */
  public getWidgetsForUser(payload: any): Observable<any> {
    return this.postRequest<any>(environment.widgetForUser, payload, this._defaultOptions);
  }
  public getWidgetData(payload: any): Observable<any> {
    return this.postRequest<any>(environment.widgetData, payload, this._defaultOptions)
  }
}
