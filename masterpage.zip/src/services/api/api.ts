export * from './example-api.service';
import { DataService } from '../data.service';
import { WidgetsService } from '../widgets-service';
import { CpProxyDataApiService } from './cp-proxy-data-api.service';
import {ExampleApiService} from "./example-api.service";
export const APIS = [ExampleApiService,DataService,WidgetsService,CpProxyDataApiService];
