import { HttpHeaders, HttpClient } from "@angular/common/http";
import { DestroyRef, inject, Injectable } from "@angular/core";

import { async, BehaviorSubject, catchError, forkJoin, from, map, mergeMap, Observable, of, ReplaySubject, shareReplay, Subject, Subscription, switchMap, takeUntil, tap } from "rxjs";
import { UserSettingsResponse } from "src/interface";
import { HttpOptionsRequestInterface } from "src/interface/http/http-options-request-interface";
import { LayoutResponse } from "src/interface/layout-response";
import { clone } from "underscore";
import { HttpAbstractBackendService } from "./api/abstract/http-abstract-backend.service";
import { environment } from 'src/environments/environment';
import { MASTERPAGEAPP } from "src/enum/constants";
import { Pages } from "src/enum/enums";
import { WidgetData } from "src/models/wideget-data";
import { WidgetsComponentsMapping } from "src/widgetmapping/widget-component-map";

import eventsMapping from '../assets/eventsmapping.json';
import { CpProxyDataApiService } from "./api/cp-proxy-data-api.service";
import { DataService } from "./data.service";
import { TIMELINE_WIDGETID } from "src/constants/constant";
import { HealthStatusOverviewComponent } from "@bakerhughes-icenter/health-status-overview-app-lib";
import { HealthStatusOverviewAdapter } from "src/adapter/HealthStatusOverviewComponetAdpater";
import { WidgetCompoenent } from "../widgetmapping/widget-component-map";
import { MicroAppService } from "./micro-app.service";

@Injectable({
    providedIn: 'root'
})
export class WidgetsService extends HttpAbstractBackendService {

    widgetDataReadyOservable: BehaviorSubject<Map<number, WidgetData>> = new BehaviorSubject(new Map());
    sigleWidgetReaday: BehaviorSubject<any> = new BehaviorSubject<any>({});
     layoutDataSingleApp: BehaviorSubject<any> = new BehaviorSubject<any>({});
    displayTimeline: BehaviorSubject<any> = new BehaviorSubject<boolean>(false);
    layoutWidgetData: BehaviorSubject<any> = new BehaviorSubject<any>({});
    widgetData: BehaviorSubject<any> = new BehaviorSubject<any>({});
     clearWidgetDataRequestSubject : Subject<any> = new Subject<any>();
     widegtForUserSubcription: any;
    widgets: any[] = []
    currentPage: any;
    destroyRef: DestroyRef = inject(DestroyRef);

    widgetsMap: Map<number, WidgetData> = new Map();

    constructor(http: HttpClient, public dataService: DataService,private microAppService: MicroAppService) {
        super(http);
        this.setApiConfig();
    }

    private setApiConfig() {
        this.baseUrl = '';
    }

    getWidgetsData(): Observable<Map<number, any>> {
        return this.widgetDataReadyOservable.asObservable();
    }
    clearWidgetData() {
        this.clearWidgetDataRequestSubject.next(true);
    }
    prapareWidgetListForPage(widgetData: Map<number, WidgetData>, fromDate: Date, currentDate: Date, layoutData: any, contextLevel: string, selectedDateRange: string) {

        var info;

        var widgetList: WidgetData[] = [];
        widgetData.forEach((widget: WidgetData, id: number) => {
            widgetList.push(widget);
        })
        widgetList
            .sort((a: WidgetData, b: WidgetData) => {
                if (a.layout.orderNUmber > b.layout.orderNUmber) return -1; return 1;
            }
            )
            .forEach((widget: WidgetData, id: number) => {
                info = WidgetsComponentsMapping.find((w: any) => { if (w.id == widget.layout.id) return w; return undefined })
                var inputs: any =this.buildStandardInput(fromDate, currentDate, layoutData, contextLevel, selectedDateRange, widget, id)
                var widthSpan = 4;

                inputs = this.manageSpecialInputCustomForWidget(info, inputs, widget);
                var output;
                ({ output, widthSpan } = this.BuildOuputObject(widget, widthSpan, info, inputs));


                this.widgets.push(output)

                console.log("Widgetid", widget?.layout?.id, "widgetdata", widget.widgetData?.data);

            });
        this.widgetDataReadyOservable.next(this.widgetsMap);
    }

    /**
     * special input for the widgtes that need custom input respect the standard input are managed here
     * @param info
     * @param inputs
     * @param widget
     * @returns
     */
    private manageSpecialInputCustomForWidget(info: WidgetCompoenent | undefined, inputs: any, widget: WidgetData) {
        if (info?.component == HealthStatusOverviewComponent) {
            inputs = {
                info1: "",
                info2: "",
                widgetData: new HealthStatusOverviewAdapter().convertWidgeta(widget.widgetData),
                title: widget.layout.title,
                showTooltip: true
            };
        }
        return inputs;
    }

    /**
     * load widget for a page
     * @param page
     * @param fromDate
     * @param currentDate
     * @param layoutData
     * @param contextLevel
     * @param selectedDateRange
     */
    preparePage(page: Pages, fromDate: Date, currentDate: Date, layoutData: any, contextLevel: any, selectedDateRange: string,microappName : string = MASTERPAGEAPP) {
        //this.clearWidgetData();
        this.layoutWidgetData.next({
            page,
            fromDate,
            currentDate,
            layoutData,
            contextLevel,
            selectedDateRange : this.dataService.selectedDateRange,
            microappName,
            // opzionale: se vuoi includere anche il vid che stai usando sotto
            level : this.dataService.getLevel(),
            selectedVid: this.microAppService?.selectedVid as any
        });

        //this.updateLayoutWidgetData(page, this.microAppService?.selectedVid as any, this.dataService.selectedDateRange, this.dataService.getLevel(), fromDate, currentDate, layoutData, contextLevel,microappName)


    }
    getWidgets(): any[] {
        return this.widgets;
    }
    /**
     * tell when single widget data is ready
     * @returns
     */
    getSigleWidgetReadyObservable(): Observable<any> {
        return this.sigleWidgetReaday.asObservable();
    }

    getLayoutDataObservable(): Observable<any> {
        return this.layoutDataSingleApp.asObservable();
    }

    prapareSignelWidgetListForPage(id: number, widget: WidgetData, fromDate: Date, currentDate: Date, layoutData: any, contextLevel: string, selectedDateRange: string) {

        var info = WidgetsComponentsMapping.find((w: any) => { if (w.id == widget.layout.id) return w; return undefined })
        var inputs: any = this.buildStandardInput(fromDate, currentDate, layoutData, contextLevel, selectedDateRange, widget, id)
        var widthSpan = 4;

        inputs = this.manageSpecialInputCustomForWidget(info, inputs, widget);

        var output;
        ({ output, widthSpan } = this.BuildOuputObject(widget, widthSpan, info, inputs));


        this.sigleWidgetReaday.next(output);
    }

    /**
     * take all information and build the output object with the widget info to be processed by page components
     * @param widget
     * @param widthSpan
     * @param info
     * @param inputs
     * @returns
     */
    private BuildOuputObject(widget: WidgetData, widthSpan: number, info: WidgetCompoenent | undefined, inputs: any) {
        if (widget.layout.widthSpan)
            widthSpan = widget.layout.widthSpan;
        var isTimeline = false;

        var output = {
            coponenetClass: info?.component,
            inputs: inputs, widthSpan: widthSpan,
            collapse: widget.widgetData?.hideWidget ? widget.widgetData?.hideWidget : false,
            showGreyImage: widget.widgetData?.showGreyImage ? widget.widgetData?.showGreyImage : false,
            showLiveData: widget.widgetData?.showLiveData ? widget.widgetData?.showLiveData : true,
            isTimeline: isTimeline,
            widgetData: widget.widgetData,
            widgetsResposes: widget
        };

        console.log("Widgetid", widget?.layout?.id, "widget infos", output);
        return { output, widthSpan };
    }
    /**
     * build the standard input for the widgets of the page
     * @param fromDate
     * @param currentDate
     * @param layoutData
     * @param contextLevel
     * @param selectedDateRange
     * @param widget
     * @param id
     * @returns
     */
    private buildStandardInput(fromDate: Date, currentDate: Date, layoutData: any, contextLevel: string, selectedDateRange: string, widget: WidgetData, id: number): any {
        return {
            fromDate: fromDate,
            currentDate: currentDate,
            layoutData: layoutData,
            contextLevel: contextLevel,
            //  dataEmpty:this.dataEmpty ,
            selectedDateRange: selectedDateRange,
            customInput1: widget,
            customInput2: widget.layout.title,
            customInput3: id
        };
    }

    getLayoutWidgetDataObservable(): Observable<any> {
        return this.layoutWidgetData.asObservable();
    }
    getWidgetDataObservable(): Observable<any> {
        return this.widgetData.asObservable();
    }
     setWidgetDataValue(obj : any): void{
        this.widgetData.next(obj);
    }
}

