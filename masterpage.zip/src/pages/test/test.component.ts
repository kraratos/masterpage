import { Component, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { auditTime, catchError, distinctUntilChanged, finalize, forkJoin, from, map, mergeMap, of, Subject, Subscription, switchMap, take, tap } from 'rxjs';
import { CpProxyDataApiService } from 'src/services/api/cp-proxy-data-api.service';
import { DataService } from 'src/services/data.service';
import { WidgetsService } from 'src/services/widgets-service';
import layoutResponse from '../../assets/layoutResponse/layoutResponse.json';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent {
  currentPage: any = Pages.STRATEGY;
  responselayout: any;
  private destroyRef: DestroyRef = inject(DestroyRef);
  items = [
    { "label": "Strategy", "icon": "emoji_objects", "key": Pages.STRATEGY },
    { "label": "Health", "icon": "speed", "key": Pages.HEALTH },
    { "label": "Efficiency & Emission", "icon": "cloud", "key": Pages.EFFICIENCY },
    { "label": "Unmanning & Remote Engineering", "icon": "settings_remote", "key": Pages.UNMANNING }
  ];



  private inflight: Subscription[] = [];
  private batch = 0; // solo per log/debug



  constructor(public dataService: DataService, private widgetsService: WidgetsService, private cpProxyDataApiService: CpProxyDataApiService,) {
    this.responselayout = layoutResponse;
   }



  ngOnInit(): void {
    // primo caricamento
    this.launchBatch(this.currentPage);
  }

  ngOnDestroy(): void {
    this.abortInflight();
  }

  pageSelected(ev: any) {
    const key: Pages = (ev?.key ?? ev) as Pages;
    this.currentPage = key;

    // 1) chiudi richieste correnti
    this.abortInflight();

    // 2) lancia il nuovo batch
    this.launchBatch(key);
  }

  private launchBatch(page: Pages) {
    // 👉 QUI scegli i 3 widget per la pagina (esempio semplice)
    const widgetIds = this.widgetIdsFor(page);   // es. [138,146,125]

    // payload comune
    const base = { vid: 'PR_NOBLE', dateRange: '3M', level: 'projects' };

    for (const widgetId of widgetIds) {
      const body = { ...base, widgetId };

      const sub = this.http.post(this.widgetUrl, body, { observe: 'response' })
        .pipe(
          take(1),
          catchError(err => {
            console.error('[ERR widget]', widgetId, err);
            return of(null);
          }),
          finalize(() => console.debug('[DONE widget]', widgetId))
        )
        .subscribe(res => {
          if (res) {
            console.log('[OK widget]', widgetId, res.status);
            // TODO: aggiorna UI come preferisci
          }
        });

      // traccia la richiesta
      this.inflight.push(sub);
      console.debug('[START widget]', widgetId);
    }
  }

  private abortInflight() {
    for (const s of this.inflight) {
      try { s.unsubscribe(); } catch {}
    }
    this.inflight = [];
  }

  private widgetIdsFor(page: Pages): number[] {
    // Metti gli ID che usi per quella pagina (puoi leggerli dal layoutResponse)
    if (page === Pages.STRATEGY) return [138, 146, 125];
    if (page === Pages.HEALTH)   return [110, 142, 150];
    return [138, 146, 125]; // fallback
  }
}




  // getWidgetsFor(page : any) :any[]{
  //    this.widgetsService.widgetsMap = new Map();

  //   this.widgetsService.layoutDataSingleApp.next(this.responselayout);

  //   const pageFound = this.responselayout?.pages?.find((p: any) => p?.name === page);

  //   const tmpWidgets: any[] = [
  //     ...(pageFound?.summary ?? [])
  //   ];
  //   if (pageFound?.kpi) tmpWidgets.push(pageFound.kpi);

  //   if (pageFound?.options) {
  //     this.dataService.setOptionsMicroAppLayoutSubject(pageFound.options);
  //   }

  //   const widgets: any[] = tmpWidgets.filter(w => w?.id !== TIMELINE_WIDGETID);
  //   return widgets;
  // }

  // pageSelected($event: any) {
  //   console.log("text click")
  //    if ($event?.detail?.key == Pages.UNMANNING) {
  //     this.currentPage = Pages.UNMANNING;

  //   }
  //   if ($event?.detail?.key == Pages.HEALTH) {
  //     this.currentPage = Pages.HEALTH;

  //   }
  //   if ($event?.detail?.key == Pages.STRATEGY) {
  //     this.currentPage = Pages.STRATEGY;

  //   }
  //   if ($event?.detail?.key == Pages.EFFICIENCY) {
  //     this.currentPage = Pages.EFFICIENCY;

  //   }
  //    this.tab$.next(this.currentPage);
  //   // this.dataService.cancelAllPendingRequest()
  //   // setTimeout(() => {
  //   //   this.updateWidgeData(Pages.STRATEGY, this.responselayout)
  //   // }, 400)

  // }
  // updateWidgeData(
  //   page: Pages,

  //   response: any
  // ) {

  //   let vid: string = "PR_NOBLE";
  //   let dataRange: string = "3M";
  //   let assetLevel: string = "projects";
  //   console.log("TEST WIDGETDATA --> updateLayoutWidgetData --> getWidgetsForUser", response)
  //   console.log("chiamate pending : ", this.dataService.cache.toString())

  //   if (!response) return;

  //   this.widgetsService.widgetsMap = new Map();

  //   this.widgetsService.layoutDataSingleApp.next(response);

  //   const pageFound = response?.pages?.find((p: any) => p?.name === page);

  //   const tmpWidgets: any[] = [
  //     ...(pageFound?.summary ?? [])
  //   ];
  //   if (pageFound?.kpi) tmpWidgets.push(pageFound.kpi);

  //   if (pageFound?.options) {
  //     this.dataService.setOptionsMicroAppLayoutSubject(pageFound.options);
  //   }

  //   const widgets: any[] = tmpWidgets.filter(w => w?.id !== TIMELINE_WIDGETID);


  //   widgets.forEach(widget => {
  //     let payload: any = {
  //       widgetId: widget.id,
  //       vid,
  //       dateRange: dataRange,
  //       level: assetLevel
  //     };
  //     if (widget.id === 110) {
  //       payload = { ...payload, sampling: 'monthly' };
  //     }

  //     this.widgetsService.widgetsMap.set(widget.id, {
  //       id: widget.id,
  //       layout: widget,
  //       widgetData: undefined,
  //       error: undefined
  //     });

  //     this.cpProxyDataService.getWidgetData(payload)
  //       .pipe(
  //         map((result: any) => ({ payload, result } as { payload: any; result: any })),
  //         takeUntilDestroyed(this.destroyRef))
  //       .subscribe(({ payload, result }) => {
  //         const widgetData = this.widgetsService.widgetsMap.get(payload.widgetId);
  //         if (!widgetData) return;

  //         if (typeof result?.data === 'string') {
  //           widgetData.error = result;
  //         } else {
  //           widgetData.widgetData = result;
  //         }
  //       });
  //   });
  // }


export const MASTERPAGEAPP = "masterpageapp";
export const TIMELINE_WIDGETID = 100;

export enum Pages {
  HEALTH = 'health',
  EFFICIENCY = "efficiency",
  STRATEGY = 'strategy',
  UNMANNING = "unmanning"
}